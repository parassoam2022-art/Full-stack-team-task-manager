
import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard(){
  const [data,setData] = useState({});
  useEffect(()=>{
    const token = localStorage.getItem("token");
    if(token){
      axios.get("http://localhost:5000/api/dashboard",{
        headers:{Authorization:`Bearer ${token}`}
      }).then(res=>setData(res.data));
    }
  },[]);

  return (
    <div>
      <h2>Dashboard</h2>
      <p>Total Tasks: {data.total}</p>
      <p>To Do: {data.todo}</p>
      <p>In Progress: {data.progress}</p>
      <p>Done: {data.done}</p>
      <p>Overdue: {data.overdue}</p>
    </div>
  );
}
